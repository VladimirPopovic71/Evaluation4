<?php

    namespace App\Models;

    use App\Core\DatabaseConnection;

    class AssociationModel {
        
        private $dbc;
        public $id_association;
        public $id_vehicule;
        public $id_conducteur;

        public function __construct(DatabaseConnection &$dbc) {
            $this->dbc = $dbc;
        }

        /**
         * @return $id - integer
         */
        public function getId()
        {
            return $this->id_association;
        }

        /**
         * @param mixed $id
         * @return $id - integer
         */
        public function setId($id)
        {
            $this->id_association = $id;
        }

        public function getByIdAssociation(int $associationId) {
            $sql = 'SELECT * FROM association_vehicule_conducteur WHERE id_association = ?;';
            $prep = $this->dbc->getConnection()->prepare($sql);
            $res = $prep->execute([$associationId]);
            $association = NULL;
            if ($res) {
                $association = $prep->fetch(\PDO::FETCH_OBJ);
            }
            return $association;
        }

        public function getAllAssociation(): array {
            $sql = 'SELECT * FROM association_vehicule_conducteur;';
            $prep = $this->dbc->getConnection()->prepare($sql);
            $res = $prep->execute();
            $associations=[];
            if ($res) {
                $associations = $prep->fetchAll(\PDO::FETCH_OBJ);
            }
            return $associations;
        }

    }
?>