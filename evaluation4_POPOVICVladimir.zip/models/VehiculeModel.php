<?php

    namespace App\Models;

    use App\Core\DatabaseConnection;

    class VehiculeModel {
        
        private $dbc;
        public $id_vehicule;
        public $marque;
        public $modele;
        public $couleur;
        public $immatriculation;

        public function __construct(DatabaseConnection &$dbc) {
            $this->dbc = $dbc;
        }

        /**
         * @return $id - integer
         */
        public function getId()
        {
            return $this->id_vehicule;
        }

        /**
         * @param mixed $id
         * @return $id - integer
         */
        public function setId($id)
        {
            $this->id_vehicule = $id;
        }

        public function getByIdVehicule(int $vehiculeId) {
            $sql = 'SELECT * FROM vehicule WHERE id_vehicule = ?;';
            $prep = $this->dbc->getConnection()->prepare($sql);
            $res = $prep->execute([$vehiculeId]);
            $vehicule = NULL;
            if ($res) {
                $vehicule = $prep->fetch(\PDO::FETCH_OBJ);
            }
            return $vehicule;
        }

        public function getAllVehicule(): array {
            $sql = 'SELECT * FROM vehicule;';
            $prep = $this->dbc->getConnection()->prepare($sql);
            $res = $prep->execute();
            $vehicules=[];
            if ($res) {
                $vehicules = $prep->fetchAll(\PDO::FETCH_OBJ);
            }
            return $vehicules;
        }

    }
?>