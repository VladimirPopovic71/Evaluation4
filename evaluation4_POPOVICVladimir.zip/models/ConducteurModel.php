<?php

    namespace App\Models;

    use App\Core\DatabaseConnection;

    class ConducteurModel {
        
        private $dbc;
        public $id_conducteur;
        public $prenom;
        public $nom;

        public function __construct(DatabaseConnection &$dbc) {
            $this->dbc = $dbc;
        }

        /**
         * @return $id - integer
         */
        public function getId()
        {
            return $this->id_conducteur;
        }

        /**
         * @param mixed $id
         * @return $id - integer
         */
        public function setId($id)
        {
            $this->id_conducteur = $id;
        }

        /**
         * @return $prenom - string
         */
        public function getPrenom()
        {
            return $this->prenom;
        }

        /**
         * @param mixed $prenom
         * @return $prenom - string
         */
        public function setPrenom($prenom)
        {
            $this->prenom = $prenom;
        }

        /**
         * @return $nom - string
         */
        public function getNom()
        {
            return $this->nom;
        }

        /**
         * @param mixed $nom
         * @return $nom - string
         */
        public function setNom($nom)
        {
            $this->nom = $nom;
        }

        public function getByIdConducteur(int $conducteurId) {
            $sql = 'SELECT * FROM conducteur WHERE id_conducteur = ?;';
            $prep = $this->dbc->getConnection()->prepare($sql);
            $res = $prep->execute([$conducteurId]);
            $conducteur = NULL;
            if ($res) {
                $conducteur = $prep->fetch(\PDO::FETCH_OBJ);
            }
            return $conducteur;
        }

        public function getAllConducteur(): array {
            $sql = 'SELECT * FROM conducteur;';
            $prep = $this->dbc->getConnection()->prepare($sql);
            $res = $prep->execute();
            $conducteurs=[];
            if ($res) {
                $conducteurs = $prep->fetchAll(\PDO::FETCH_OBJ);
            }
            return $conducteurs;
        }

        public function getByNom(string $conducteurNom) {
            $sql = 'SELECT * FROM conducteur WHERE nom = ?;';
            $prep = $this->dbc->getConnection()->prepare($sql);
            $res = $prep->execute([$conducteurNom]);
            $conducteur = NULL;
            if ($res) {
                $conducteur = $prep->fetch(\PDO::FETCH_OBJ);
            }
            return $conducteur;
        }

        public function getByPrenom(string $conducteurPrenom) {
            $sql = 'SELECT * FROM conducteur WHERE prenom = ?;';
            $prep = $this->dbc->getConnection()->prepare($sql);
            $res = $prep->execute([$conducteurPrenom]);
            $conducteur = NULL;
            if ($res) {
                $conducteur = $prep->fetch(\PDO::FETCH_OBJ);
            }
            return $conducteur;
        }

    }
?>