<!doctype html>
<html lang="fr">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Evaluation 4 - POPOVIC Vladimir</title>

    <link rel="stylesheet" href="/public/css/main.css" type="text/css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/public/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/a5554aaee0.js" crossorigin="anonymous"></script>
    
  </head>
  <body>

     <!-- Main navigation -->
     <header class="site-header bg-dark border-bottom border-dark">
      <a href="#content" class="sr-only sr-only-focusable">Skip to content</a>
      <div class="container">
          <!-- Navbar -->
          <nav class="navbar main-nav navbar-expand-lg navbar-dark" aria-label="Main navigation">
              <a href="http://127.0.0.1/public/pages/conducteur.php" class="navbar-brand d-inline-flex text-uppercase">Evaluation 4 - POPOVIC Vladimir</a>              

              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
              <div class="collapse navbar-collapse text-uppercase" id="navbarContent">
                  <ul class="navbar-nav ml-auto">
                      <li class="nav-item">
                          <a href="http://127.0.0.1/public/pages/conducteur.php" class="nav-link">Conducteur</a>                          
                      </li>
                      <li class="nav-item">
                          <a href="http://127.0.0.1/public/pages/association_vehicule_conducteur.php" class="nav-link">Association Vehicule Conducteur</a>
                      </li>
                      <li class="nav-item">
                        <a href="http://127.0.0.1/public/pages/vehicule.php" class="nav-link">Vehicule</a>
                      </li>
                  </ul>
              </div>

          </nav>
      </div>
    </header>
    <!-- end main navigation -->