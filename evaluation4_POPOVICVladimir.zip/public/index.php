<?php

    ob_start();    
    require_once '../vendor/autoload.php';
    //require dirname(__DIR__) . '/vendor/autoload.php';

    use App\Core\DatabaseConfiguration;
    use App\Core\DatabaseConnection;
    use App\Models\ConducteurModel;
    
    $databaseConfiguration = new DatabaseConfiguration('localhost','root','fe10022020','vtc');
    $databaseConnection = new DatabaseConnection($databaseConfiguration);
    
    $conducteurModel= new ConducteurModel($databaseConnection);
    // une liste de tous les objets conducteurs
    $conducteurs = $conducteurModel->getAllConducteur();


    $request = $_SERVER['REQUEST_URI'];
    $uri = parse_url($request, PHP_URL_PATH);

    switch ($uri) {
        case '/':
            require __DIR__ . '/pages/conducteur.php';
            break;
        case '/conducteur':
            require __DIR__ . '/pages/conducteur.php';
            break;
        case '/association_vehicule_conducteur':
            require __DIR__ . '/pages/association_vehicule_conducteur.php';
            break;
        case '/vehicule':
            require __DIR__ . '/pages/vehicule.php';
            break;
            
        default:
            //require __DIR__ . '/pages/conducteur.php';
            require 'http://127.0.0.1/public/pages/conducteur.php';            
            break;
    }   

    ob_end_flush();    
?>