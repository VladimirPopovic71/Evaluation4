<?php 
    require ('../../core/header.php'); 

    use App\Core\DatabaseConfiguration;
    use App\Core\DatabaseConnection;
    use App\Models\ConducteurModel;

    $databaseConfiguration = new DatabaseConfiguration('localhost','root','fe10022020','vtc');
    $databaseConnection = new DatabaseConnection($databaseConfiguration);
    
    $conducteurModel= new ConducteurModel($databaseConnection);
    // une liste de tous les objets conducteurs
    $conducteurs = $conducteurModel->getAllConducteur();
    //print_r($conducteurs);

    $error = "";
    $id = $prenom = $nom = "";

    if (isset($_POST['submit'])) { 
    
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            
            $prenom = htmlentities($_POST['prenom'], ENT_QUOTES);	    
            $nom = htmlentities($_POST['nom'], ENT_QUOTES);		
    
            if(empty($prenom)) { $error .= "<strong>Prenom</strong>, "; }
            if(empty($nom)) { $error .= "<strong>Nom</strong>, "; }
            
            //méthodes d'objet pour écrire, mettre au monde ou supprimer des données via un objet
        }

    }
?>

<div class="container">
    <div class="row my-5">
        <div class="col text-center">
            <h2>Conducteur</h2>
        </div>
    </div>

    <!-- table -->
    <div class="row">    
        <table id="user_data" class="table table-hover table-bordered">
            <thead class="thead-dark">
                <tr>                            
                    <th># ID conducteur</th>                    
                    <th>Prenom</th>
                    <th>Nom</th>                    
                    <th width="160px">Action</th>
                </tr>
            </thead>
            <tbody>                        
                <?php foreach($conducteurs as $conducteur){?>
                    <tr>
                        <td><?php echo ($conducteur->id_conducteur); ?></td>                        
                        <td><strong><?php echo ($conducteur->prenom); ?></strong></td>
                        <td><?php echo ($conducteur->nom); ?></td>
                        <td>  
                            <a href="/conducteur?action=edit&id=<?php echo ($conducteur->id_conducteur); ?>" class="btn btn-warning mb-1"><i class="far fa-pen"></i></a>    
                            <a href="/conducteur?action=delete&id=<?php echo ($conducteur->id_conducteur); ?>" class="btn btn-danger mb-1"><i class="far fa-times"></i></a>                                
                        </td>                    
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <!-- end table -->

    <br><br>

    <!-- Forma -->
    <div class="row d-flex flex-row justify-content-center align-items-center">
       <div class="col-11 m-5 p-4 text-left alert alert-secondary" role="alert">            
           <form action="" method="post">                        
               <div class="row">
                   <div class="col text-center"><h2>Forma conducteur</h2></div>
               </div>
               <?php if ($error!="") { ?>
                    <div class="row text-center">
                        <div class="col alert alert-danger" role="alert">
                            <?php echo($error); ?>
                        </div>
                    </div>
                <?php } ?>
                <br>
                <div class="row">
                    <div class="col">
                        <div class="form-group row">
                            <label for="prenom" class="col-md-4 col-form-label text-right">Prenom</label>                                                
                            <div class="col-md-8">
                                <input type="text" name="prenom" class="form-control" id="prenom" value="<?php echo $prenom; ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="nom" class="col-md-4 col-form-label text-right">Nom</label>                                                
                            <div class="col-md-8">
                                <input type="text" name="nom" class="form-control" id="nom" value="<?php echo $nom; ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="form-group row text-left">                                                    
                    <div class="col text-right">
                        <button type="submit" class="btn btn-primary " name="submit">S'inscrire</button>                                
                    </div>                    
                </div>    
            </form>           

        </div>
    </div>
    <!-- end forma -->

</div>

<?php require ('../../core/footer.php');  ?>