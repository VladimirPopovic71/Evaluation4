<?php 

    require ('../../core/header.php'); 

    use App\Core\DatabaseConfiguration;
    use App\Core\DatabaseConnection;
    use App\Models\AssociationModel;

    $databaseConfiguration = new DatabaseConfiguration('localhost','root','fe10022020','vtc');
    $databaseConnection = new DatabaseConnection($databaseConfiguration);
    
    $associationModel= new AssociationModel($databaseConnection);
    // une liste de tous les objets vehicules
    $associations = $AssociationModel->getAllAssociation();
    //print_r($associations);
    
?>

<div class="container">
    <div class="row my-5">
        <div class="col text-center">
            <h2>Association Vehicule Conducteur</h2>
        </div>
    </div>

    
    <!-- table -->
    <div class="row">    
        <table id="user_data" class="table table-hover table-bordered">
            <thead class="thead-dark">
                <tr>                            
                    <th># ID Association</th>                    
                    <th>Vehicule</th>
                    <th>Conducteur</th>                    
                    <th width="160px">Action</th>
                </tr>
            </thead>
            <tbody>                        
                <?php foreach($associations as $association){?>
                    <tr>
                        <td><?php echo ($association->id_association); ?></td>                        
                        <td><strong><?php echo ($association->vehicule); ?></strong></td>
                        <td><?php echo ($association->conducteur); ?></td>
                        <td>  
                            <a href="/conducteur?action=edit&id=<?php echo ($association->id_association); ?>" class="btn btn-warning mb-1"><i class="far fa-pen"></i></a>    
                            <a href="/conducteur?action=delete&id=<?php echo ($association->id_association); ?>" class="btn btn-danger mb-1"><i class="far fa-times"></i></a>                                
                        </td>                    
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <!-- end table -->

    <br><br>

    <!-- Forma -->
    <div class="row d-flex flex-row justify-content-center align-items-center">
       <div class="col-11 m-5 p-4 text-left alert alert-secondary" role="alert">            
           <form action="" method="post">                        
               <div class="row">
                   <div class="col text-center"><h2>Form Association Vehicule Conducteur</h2></div>
               </div>
               <?php if ($error!="") { ?>
                    <div class="row text-center">
                        <div class="col alert alert-danger" role="alert">
                            <?php echo($error); ?>
                        </div>
                    </div>
                <?php } ?>
                <br>
                <div class="row">
                    <div class="col">
                        <div class="form-group row">
                            <label for="association" class="col-md-4 col-form-label text-right">Association</label>                                                
                            <div class="col-md-8">
                                <input type="text" name="association" class="form-control" id="association" value="<?php echo $association; ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-8">
                                <input type="text" name="vehicule" class="form-control" id="vehicule" value="<?php echo $vehicule; ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="conducteur" class="col-md-4 col-form-label text-right">Conducteur</label>                                                
                            <div class="col-md-8">
                                <input type="text" name="conducteur" class="form-control" id="conducteur" value="<?php echo $conducteur; ?>">
                            </div>
                        </div>

                    </div>
                </div>
                <hr>
                <div class="form-group row text-left">                                                    
                    <div class="col text-right">
                        <button type="submit" class="btn btn-primary " name="submit">S'inscrire</button>                                
                    </div>                    
                </div>    
            </form>           

        </div>
    </div>
    <!-- end forma -->

</div>

<?php require ('../../core/footer.php');  ?>